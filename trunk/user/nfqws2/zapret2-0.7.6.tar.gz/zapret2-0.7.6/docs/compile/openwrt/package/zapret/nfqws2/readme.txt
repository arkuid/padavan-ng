Copy "nfq2" folder here !
